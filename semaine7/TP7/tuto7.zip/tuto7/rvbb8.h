#ifndef RVBB8_H
#define RVBB8_H

#include "rvmodel.h"



class RVBB8 : public RVModel
{
public:
    RVBB8();
};

#endif // RVBB8_H
