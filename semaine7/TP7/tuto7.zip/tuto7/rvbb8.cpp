#include "rvbb8.h"

RVBB8::RVBB8(): RVModel("/home/bonnet/Documents/cours-si5/RV/semaine7/final/tuto7/BB8/bb8.obj")
{

}
